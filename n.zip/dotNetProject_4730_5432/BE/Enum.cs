﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



    namespace BE
    {
        public enum vehicle { private_auto, car_TwoWheels, Medium_truck, Heavy_truck };
        public enum Transmission { manual, auto };
        public enum gender { male, female };
    }

