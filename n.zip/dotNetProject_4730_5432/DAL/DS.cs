﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DataSource
    {
        
           public  static List<BE.Tester> l1 = new List<BE.Tester> ();
           public  static List<BE.Trainee> l2 = new List<BE.Trainee>() ;
            public static List<BE.Test> l3 = new List<BE.Test> ();
        
    }
}
